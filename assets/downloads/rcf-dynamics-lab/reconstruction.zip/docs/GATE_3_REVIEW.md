# Gate 3 scientific review

Owner approved the UI and then authorized continued local analysis and online map research on November 17, 2026.

## Evidence produced

The original uploaded MOV decodes to 449 portrait frames. Actual presentation timestamps are separated by 1/30 second, with the final frame at 14.9333 seconds and browser media duration 14.97 seconds. The analysis uses a 540 × 960 derivative of the original 2160 × 3840 presentation.

The [City of Charlotte 2024 aerial map service](https://gis.charlottenc.gov/arcgis/rest/services/WEB/Aerial24/MapServer) provides a georeferenced image of the exact intersection. The public geocoder returned a street-intersection match at approximately 35.220756 N, 80.845538 W. That coordinate identifies the vicinity and supplies no vehicle location.

Ground pixel size near the intersection is about 0.112 metres in the downloaded 2048 × 2048 aerial. EPSG:3857 coordinates were transformed to UTM zone 17N for distance calculations, accounting for the local Mercator scale factor.

Six manually selected ground-paint controls fit the Apple screenshot to the aerial with about 0.57 m RMS. Two held-out controls have errors of 1.26 m and 1.29 m. Leave-one-out tests across all eight controls range from approximately 1.03 m to 1.62 m. These are exploratory registration errors. Absolute source geolocation error and systematic marking-selection errors are additional. The manual selections require review.

The initial automated map matching failed review. SIFT produced only six RANSAC inliers, including a duplicate and a geometrically implausible match. That transform was rejected. The reported calibration uses explicit manually selected ground-paint controls.

## Image tracking and validation

Shi–Tomasi feature detection and pyramidal Lucas–Kanade tracking operate inside manually selected building/tree candidate regions. Forward/backward consistency must be below 0.75 analysis pixels. A per-pair RANSAC homography uses a 1.5 px threshold, at least eight inliers and at least a 60% inlier fraction. These checks measure image-model consistency. They do not establish each point as a stationary 3D landmark.

The final conservative filter retains 322 frame pairs, with a median of 57 scene-model inliers per retained pair. The 7.4–10.6 second interval is excluded because of passenger occlusion, glare and rapid camera movement. Other pairs that fail support thresholds return no overlay output. The review page exposes those gaps.

Two manually initialized scene landmarks were tracked for independent endpoint comparisons. At 2 seconds, their endpoint errors against manual labels were 2.07 px and 1.34 px. At 4 seconds, one chain had already failed its round-trip criterion, despite ending near the manual endpoint. The other endpoint differed by 3.20 px, slightly outside the provisional 3 px manual-label tolerance. These failures are retained. This limited validation supports inspection of early-scene tracks and does not validate the entire clip.

Sensitivity checks vary the forward/backward threshold from 0.4 px to 1.2 px on sampled frame pairs. Full numerical results, including missing support, are in analysis/outputs/tracking-sensitivity.json and validation.json.

The wheel patch provides experimental local image-plane rotation estimates over the initially visible interval. The fitted cabin display motion is subtracted. The experiment lacks an independently validated wheel-plane transform and loses useful visibility during the maneuver, so the data exports no steering-wheel angle in physical telemetry.

## Quantities still unresolved

| Output | Status after this run | Missing constraint |
|---|---|---|
| Frame timestamps | Observed | Verified against the decoded presentation timestamps |
| Feature pixel positions and displacement | Observed candidate tracks | Broader manual validation and stationary-scene confirmation |
| Overhead image registration | Exploratory inferred transform | Reviewed controls and source accuracy |
| Steering-wheel rotation | Unavailable as physical telemetry | Wheel-plane calibration, hand masks and reliable turn unwrapping |
| Vehicle ground position and speed | Unavailable | Matched video-to-ground points and validated camera geometry |
| Body heading and yaw rate | Unavailable | Camera-to-body motion correction and independent orientation constraints |
| Sideslip | Unavailable | Independently constrained heading and ground velocity |
| Event torque and tire forces | Unavailable | Independent drivetrain and vehicle-state observations |
| Reported full 360-degree body rotation | Unverified | Continuous orientation evidence through occluded intervals |

An online map fixes the geometry of the surroundings. Recovering the car's trajectory additionally requires matching visible video evidence to that geometry and accounting for phone movement. Fitting the owner's approximate path would encode the prior sketch without independently measuring the event.

No physical dynamics fit was attempted because its required pose observations did not pass the prerequisite stage. Every physical telemetry field in observations.json is null. The existing replay's route, headings, vectors and time progression remain illustrative.

## Review artifacts

- Local interactive review at http://127.0.0.1:4173/review overlays the actual candidate tracks on the original footage.
- analysis/outputs/tracking-review.mp4 is a silent private annotated diagnostic clip.
- analysis/outputs/map-calibration.png identifies the fit and held-out controls.
- analysis/outputs/tracking-diagnostics.png shows tracking support, errors, image displacement and experimental wheel-patch increments over time.
- analysis/outputs/observations.json stores timestamped points, validity and provenance.
- analysis/outputs/validation.json records the independent endpoint failures and sensitivity summaries.
- analysis/requirements.lock pins the project-local environment. The source scripts reproduce ingest, retrieval, calibration, tracking and validation.

Chrome checks covered actual decoding, frame-index synchronization, overlay-off clearing, excluded intervals, diagnostic images and mobile width. Python checks covered timestamp ordering, missing physical telemetry, exclusion intervals and finite JSON. Package dependency checks passed. Safari validation remains pending.

## Decision requested

Review the ground controls and tracking diagnostics. Approve accepted image-space outputs and the exploratory map alignment for the next replay revision, or identify controls/intervals to revise. Physical motion measurements require further calibration and validation. Project instructions require scientific review before integrating accepted measurements into the polished replay.
