# RC F reconstruction evidence

This package contains source code, official map-service records and numerical outputs for the accompanying article. It includes the original CV observations and validation failures, plus separate model-assisted estimates.

Use analysis/README.md for setup and docs/HYBRID_RECONSTRUCTION.md for assumptions and checks. Source video, frame imagery, map screenshots and supplied artwork require separately authorized local inputs.

The model results are conditional on manually selected map controls, route priors, timing, friction and vehicle assumptions.
