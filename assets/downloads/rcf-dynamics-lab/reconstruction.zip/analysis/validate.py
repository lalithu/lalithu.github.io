"""Validate image tracks against manual endpoints and audit generated outputs."""
import json
from pathlib import Path
import cv2
import numpy as np

ROOT=Path(__file__).parent
OUT=ROOT/"outputs"
cached=np.load(OUT/"frames.npz")
images=cached["images"]
times=cached["timestamps"]
observations=json.loads((OUT/"observations.json").read_text())
assert len(images)==449==len(observations["frames"])
assert np.all(np.diff(times)>0)
assert np.max(abs(np.diff(times)-1/30))<1e-10
assert all(value is None for value in observations["telemetry"].values())
assert all(not r["exterior"] for r in observations["frames"] if 7.4<=r["t"]<=10.6)

# Held-out visible sign/pole landmarks. Labels selected independently from
# enlarged source crops. Evaluation points never enter feature fitting.
landmarks=[
 {"id":"left-dark-sign-upper-left","initial_px":[44,469],"labels":[{"t":2,"xy":[29,406]},{"t":4,"xy":[8,409]}]},
 {"id":"yellow-pole-top","initial_px":[145,464],"labels":[{"t":2,"xy":[135,402]},{"t":4,"xy":[124,407]}]},
]
clahe=cv2.createCLAHE(clipLimit=2,tileGridSize=(8,8))
previous=clahe.apply(cv2.cvtColor(images[0],cv2.COLOR_BGR2GRAY))
points=np.array([p["initial_px"] for p in landmarks],np.float32).reshape(-1,1,2)
valid=np.ones(len(landmarks),bool)
results=[]
for i in range(1,121):
 gray=clahe.apply(cv2.cvtColor(images[i],cv2.COLOR_BGR2GRAY))
 moved,status,_=cv2.calcOpticalFlowPyrLK(previous,gray,points,None,winSize=(21,21),maxLevel=3,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
 back,reverse,_=cv2.calcOpticalFlowPyrLK(gray,previous,moved,None,winSize=(21,21),maxLevel=3,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
 valid &= status.ravel().astype(bool)&reverse.ravel().astype(bool)&(np.linalg.norm(points-back,axis=2).ravel()<.75)
 points=moved
 for j,landmark in enumerate(landmarks):
  for label in landmark["labels"]:
   if abs(times[i]-label["t"])<.001:
    prediction=points[j,0]
    error=float(np.linalg.norm(prediction-label["xy"]))
    results.append({"landmark":landmark["id"],"t":label["t"],"manual_px":label["xy"],"tracked_px":prediction.tolist(),"error_px":error,"chain_valid":bool(valid[j])})
 previous=gray

stats=json.loads((OUT/"tracking-summary.json").read_text())
sens=json.loads((OUT/"tracking-sensitivity.json").read_text())
pairs={}
for entry in sens:
 if entry["stats"] is not None:
  pairs.setdefault(entry["frame"],{})[entry["threshold_px"]]=entry["stats"]
count_deltas=[]
motion_deltas=[]
for pair in pairs.values():
 if .4 in pair and 1.2 in pair:
  count_deltas.append(abs(pair[.4]["inliers"]-pair[1.2]["inliers"]))
  left,right=pair[.4]["median_displacement_px"],pair[1.2]["median_displacement_px"]
  if left is not None and right is not None:motion_deltas.append(abs(left-right))
validation={
 "heldout_video_landmarks":results,
 "manual_label_tolerance_px":3,
 "heldout_scope":"Two landmarks in early unoccluded scene; no claim of whole-clip accuracy",
 "threshold_sensitivity":{"tested_fb_thresholds_px":[.4,1.2],"compared_pairs":len(count_deltas),"max_scene_inlier_count_difference":max(count_deltas,default=None),"max_median_image_motion_difference_px_per_frame":max(motion_deltas,default=None)},
 "checks":["449 monotonically ordered timestamps","nominal 1/30 s deltas verified against decoded timestamps","all physical telemetry null","blocked interval exports no scene tracks","JSON is finite and parseable"],
 "limitations":["Manual labels are approximate and need reviewer confirmation.","Forward/backward residual alone does not prove a point is stationary.","Threshold sensitivity covers sampled pairs only.","Wheel-patch rotation lacks independent validation and remains experimental."],
}
(OUT/"validation.json").write_text(json.dumps(validation,indent=2))
print(json.dumps(validation,indent=2))
