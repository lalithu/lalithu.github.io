"""Fit an exploratory ground-plane transform using manual map correspondences."""
import argparse
import json
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).parent / "cache/mpl"))
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from pyproj import Transformer

parser=argparse.ArgumentParser()
parser.add_argument("--apple-map",type=Path,required=True)
args=parser.parse_args()

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)
# Manual selections from coordinate grids, 2026-11-17.
# Ground paint only. Selection uncertainty is approximate and must be reviewed.
controls = [
    ("NW checker north tip", [1809, 1036], [1029, 839]),
    ("NW checker south tip", [1633, 1269], [942, 951]),
    ("NW stop stripe SW end", [1563, 1201], [894, 922]),
    ("NE checker south tip", [2223, 1324], [1217, 983]),
    ("South isolated diamond", [1971, 1614], [1109, 1131]),
    ("South stop stripe SW end", [2105, 1627], [1165, 1143]),
    ("NE stop stripe SE end", [2166, 1108], [1204, 886]),
    ("NW stop stripe NE end", [1758, 1045], [1011, 849]),
]
a = np.array([p[1] for p in controls], dtype=np.float64)
b = np.array([p[2] for p in controls], dtype=np.float64)
fit_indices = [0, 2, 3, 4, 5, 7]
heldout_indices = [1, 6]
fit_a, fit_b = a[fit_indices], b[fit_indices]
H, _ = cv2.findHomography(fit_a, fit_b, 0)
def project(points, transform):
    return cv2.perspectiveTransform(points[None].astype(float), transform)[0]
export = json.loads((ROOT / "cache/aerial-export.json").read_text())["response"]
extent = export["extent"]
resolution = (extent["xmax"] - extent["xmin"]) / export["width"]
to_geo = Transformer.from_crs(3857, 4326, always_xy=True)
to_local = Transformer.from_crs(4326, 32617, always_xy=True)
def local_m(points):
    mx = extent["xmin"] + points[:,0]*resolution
    my = extent["ymax"] - points[:,1]*resolution
    lon, lat = to_geo.transform(mx,my)
    east,north = to_local.transform(lon,lat)
    return np.column_stack([east,north])
target_m = local_m(b)
errors = np.linalg.norm(local_m(project(a,H))-target_m,axis=1)
loo=[]
for i in range(len(a)):
    keep=np.arange(len(a)) != i
    h,_=cv2.findHomography(a[keep],b[keep],0)
    loo.append(float(np.linalg.norm(local_m(project(a[i:i+1],h))[0]-target_m[i])))
origin = local_m(np.array([[1024,1024]],float))[0]
results = {
    "kind":"inferred",
    "status":"exploratory map registration, manual controls awaiting review",
    "source_url":"https://gis.charlottenc.gov/arcgis/rest/services/WEB/Aerial24/MapServer",
    "aerial_year":2024,
    "source_pixel_crs":"EPSG:3857",
    "local_crs":"EPSG:32617",
    "origin_utm_m":origin.tolist(),
    "apple_to_aerial_homography":H.tolist(),
    "aerial_extent":extent,
    "aerial_resolution_web_mercator_units_per_pixel":resolution,
    "aerial_ground_resolution_near_intersection_m_per_pixel":float(np.linalg.norm(local_m(np.array([[1024,1024],[1025,1024]],float))[1]-origin)),
    "fit_rms_m":float(np.sqrt(np.mean(errors[fit_indices]**2))),
    "heldout_errors_m":errors[heldout_indices].tolist(),
    "leave_one_out_errors_m":loo,
    "controls":[{"label":p[0],"apple_px":p[1],"aerial_px":p[2],"role":"heldout" if i in heldout_indices else "fit","local_en_m":(target_m[i]-origin).tolist(),"error_m":float(errors[i])} for i,p in enumerate(controls)],
    "limitations":["Manual point picks have not received owner review.","Image dates differ; markings may have changed.","Residuals test map registration, not vehicle pose.","Reported errors omit source orthorectification and absolute geolocation error.","Mercator map units were transformed to UTM ground metres."],
}
(OUT/"map-calibration.json").write_text(json.dumps(results,indent=2))
fig,axes=plt.subplots(1,2,figsize=(14,7),layout="constrained")
clean=Image.open(args.apple_map)
aerial=Image.open(ROOT/"cache/aerial-2024.png")
for ax,im,points,title,limits in [
    (axes[0],clean,a,"Apple Maps reference — ground controls",(1450,2390,1760,900)),
    (axes[1],aerial,b,"City of Charlotte 2024 aerial",(850,1330,1210,790)),
]:
    ax.imshow(im); ax.set_xlim(limits[:2]);ax.set_ylim(limits[2:])
    for i,xy in enumerate(points):
        color="#c57600" if i in heldout_indices else "#5856d6"
        ax.scatter(*xy,s=45,c=color,edgecolors="white",linewidths=1)
        ax.annotate(str(i+1),xy,xytext=(6,4),textcoords="offset points",color="white",weight="bold",bbox=dict(facecolor=color,alpha=.85,pad=1))
    ax.set_title(title);ax.set_xlabel("Source image pixels")
fig.suptitle("Exploratory calibration · violet = fit, amber = held out",fontsize=15)
fig.savefig(OUT/"map-calibration.png",dpi=140)
print({k:results[k] for k in ["aerial_ground_resolution_near_intersection_m_per_pixel","fit_rms_m","heldout_errors_m","leave_one_out_errors_m"]})
