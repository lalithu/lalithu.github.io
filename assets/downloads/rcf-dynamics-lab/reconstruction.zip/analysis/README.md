# Local analysis and scientific review

Gate 3 produces image-space observations and exploratory map calibration. Physical vehicle telemetry remains null pending camera geometry, video-to-ground correspondence and independent validation.

Use Python 3.11 with a local virtual environment.

```sh
python3.11 -m venv analysis/.venv
analysis/.venv/bin/python -m pip install -r analysis/requirements.lock
analysis/.venv/bin/python analysis/fetch_maps.py
analysis/.venv/bin/python analysis/ingest.py /absolute/path/to/IMG_1375.MOV
analysis/.venv/bin/python analysis/calibrate_map.py --apple-map /absolute/path/to/clean-map.png
analysis/.venv/bin/python analysis/track.py
analysis/.venv/bin/python analysis/validate.py
```

The map script uses manually selected source-pixel controls for the owner's 4112 × 2658 screenshot. A different screenshot requires replacement controls. The ingestion rotation is specific to this clip and was checked visually. Source images and files in analysis/cache and analysis/outputs are private and gitignored.

The pipeline exports decoded timestamps, image features, per-pair inlier masks, forward/backward errors, exploratory wheel-patch transforms, calibration residuals, held-out landmark checks and sensitivity results. A silent annotated diagnostic MP4 supports frame review. The original audio remains in the original private video.

The review page is available at http://127.0.0.1:4173/review while the local replay server is running.

## Scientific limits recorded by the run

- Map calibration uses six manually selected ground controls and two held-out controls. Manual point selection, source geolocation and changed markings contribute uncertainty.
- Scene-model inliers measure consistency with a pairwise homography. This alone cannot establish stationary 3D points or metric vehicle speed.
- Two manually labeled early-scene landmarks provide a limited held-out check. A lost tracking chain and an endpoint just outside the declared 3 px tolerance are retained in the validation results.
- Wheel-patch transforms measure apparent image-plane rotation relative to a display patch. Steering wheel angle and unwrapped full turns remain unavailable.
- Phone movement, passenger occlusion and glare exclude 7.4–10.6 seconds from the initial scene output.
- Physical heading, yaw rate, velocity, sideslip and event torque remain null in the data.

## Hybrid reconstruction authorized by revised Gate 3

The owner subsequently authorized model-assisted physical estimates. The preserved original observations still contain null physical telemetry. New conditional reconstruction outputs are written separately.

```sh
analysis/.venv/bin/python analysis/prepare_hybrid.py
node analysis/fit_hybrid.mjs
analysis/.venv/bin/python analysis/diagnose_hybrid.py
```

The fit uses the shared browser/offline solver in replay/hybrid-model.mjs. See docs/HYBRID_RECONSTRUCTION.md for the parameter assessment, source provenance, model checks, alternative solutions and unresolved uncertainties.
