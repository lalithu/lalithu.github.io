"""Decode actual presentation timestamps and create a private contact sheet."""
import argparse
import json
from pathlib import Path

import av
import cv2
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("video", type=Path)
parser.add_argument("--output", type=Path, default=Path(__file__).parent / "outputs")
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
container = av.open(str(args.video))
stream = container.streams.video[0]
print("Stream", stream.width, stream.height, stream.metadata)
timestamps = []
frames = []
for frame in container.decode(stream):
    t = float(frame.pts * frame.time_base)
    image = frame.to_ndarray(format="bgr24")
    if image.shape[1] > image.shape[0]:
        image = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)
    image = cv2.resize(image, (540, 960), interpolation=cv2.INTER_AREA)
    frames.append(image)
    timestamps.append(t)
container.close()
times = np.array(timestamps)
times -= times[0]
np.savez_compressed(args.output / "frames.npz", images=np.array(frames), timestamps=times)
metadata = {
    "frame_count": len(frames),
    "first_pts_seconds": timestamps[0],
    "last_relative_pts_seconds": float(times[-1]),
    "delta_min_seconds": float(np.min(np.diff(times))),
    "delta_max_seconds": float(np.max(np.diff(times))),
    "analysis_width": 540,
    "analysis_height": 960,
    "rotation": "clockwise 90 degrees when decoded width exceeds height",
}
(args.output / "ingest.json").write_text(json.dumps(metadata, indent=2))
print(metadata)
sheet = np.full((4 * 420, 4 * 240, 3), 249, np.uint8)
indices = [int(np.argmin(abs(times-t))) for t in np.linspace(0, times[-1], 16)]
for tile, index in enumerate(indices):
    x = (tile % 4) * 240
    y = (tile // 4) * 420
    thumb = cv2.resize(frames[index], (225, 400))
    sheet[y+20:y+420, x:x+225] = thumb
    cv2.putText(sheet, f"{times[index]:.3f} s / frame {index+1}", (x+3, y+14), cv2.FONT_HERSHEY_SIMPLEX, .36, (35,35,35), 1, cv2.LINE_AA)
cv2.imwrite(str(args.output / "contact-sheet.jpg"), sheet)
for t in [0, 2, 4, 6, 8, 10, 12, 14]:
    i = int(np.argmin(abs(times-t)))
    cv2.imwrite(str(args.output / f"frame-{t:02d}.jpg"), frames[i])
