"""Classical image-space diagnostics with conservative, manually selected ROIs."""
import json
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).parent/"cache/mpl"))

import av
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).parent
OUT=ROOT/"outputs"
data=np.load(OUT/"frames.npz")
images=data["images"]
times=data["timestamps"]
height,width=images.shape[1:3]

# Rectangles were selected from the contact sheets at integer seconds.
# They select building/tree candidates and the cabin display. Intervening
# positions are provisional masks, checked by FB consistency and RANSAC.
scene_rois=np.array([
 [[20,425,175,475],[417,388,527,442]],
 [[15,393,179,455],[426,367,527,420]],
 [[15,361,211,418],[423,347,527,402]],
 [[15,355,207,408],[425,339,527,397]],
 [[15,372,202,422],[431,363,527,413]],
 [[25,415,249,461],[500,415,531,455]],
 [[170,445,298,478],[506,471,533,498]],
 [[25,357,243,403],[453,365,528,418]],
 [[125,333,227,404],[125,333,227,404]],
 [[5,332,60,411],[172,348,215,388]],
 [[42,350,100,420],[42,350,100,420]],
 [[166,391,327,443],[502,406,531,468]],
 [[45,405,173,436],[355,408,419,488]],
 [[88,346,203,379],[413,397,502,441]],
 [[16,337,149,387],[393,357,499,403]],
],float)
cabin_rois=np.array([
 [286,579,437,637],[281,553,429,607],[286,520,429,568],
 [276,508,420,555],[285,524,421,573],[340,582,469,622],
 [372,610,502,664],[337,540,471,588],[5,476,135,518],
 [99,469,228,511],[248,512,365,555],[385,553,519,596],
 [237,569,386,616],[263,520,405,565],[264,489,404,532],
],float)
wheel_rois=np.array([[32,649,135,693],[34,617,137,660],[30,588,133,636],[24,566,128,611]],float)
lk=dict(winSize=(21,21),maxLevel=3,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
clahe=cv2.createCLAHE(clipLimit=2,tileGridSize=(8,8))
def roi_at(t, table):
    lower=min(int(t),len(table)-1)
    upper=min(lower+1,len(table)-1)
    return table[lower]+min(1,t-lower)*(table[upper]-table[lower])

def mask_from_rects(rects):
    mask=np.zeros((height,width),np.uint8)
    for rect in np.atleast_2d(rects):
        x1,y1,x2,y2=np.round(rect).astype(int)
        cv2.rectangle(mask,(max(0,x1),max(0,y1)),(min(width-1,x2),min(height-1,y2)),255,-1)
    return mask

def candidates(previous,current,mask,next_mask,threshold=.75):
    p=cv2.goodFeaturesToTrack(previous,maxCorners=140,qualityLevel=.015,minDistance=6,mask=mask,blockSize=5)
    if p is None or len(p)<4: return None
    q,status,_=cv2.calcOpticalFlowPyrLK(previous,current,p,None,**lk)
    back,reverse,_=cv2.calcOpticalFlowPyrLK(current,previous,q,None,**lk)
    p,q,back=p.reshape(-1,2),q.reshape(-1,2),back.reshape(-1,2)
    fb=np.linalg.norm(p-back,axis=1)
    inside=(q[:,0]>=0)&(q[:,0]<width)&(q[:,1]>=0)&(q[:,1]<height)
    indices=np.round(q).astype(int)
    indices[:,0]=np.clip(indices[:,0],0,width-1);indices[:,1]=np.clip(indices[:,1],0,height-1)
    keep=status.ravel().astype(bool)&reverse.ravel().astype(bool)&inside&(fb<threshold)&(next_mask[indices[:,1],indices[:,0]]>0)
    return p[keep],q[keep],fb[keep],len(p)

def similarity(p,q):
    if len(p)<5:return None,None
    matrix,inliers=cv2.estimateAffinePartial2D(p,q,method=cv2.RANSAC,ransacReprojThreshold=1,maxIters=3000,confidence=.995)
    return matrix,inliers

def homography_tracks(previous,current,mask,next_mask,threshold):
    tracked=candidates(previous,current,mask,next_mask,threshold)
    if tracked is None:return [],None
    p,q,fb,detected=tracked
    if len(p)<8:return [],None
    H,valid=cv2.findHomography(p,q,cv2.RANSAC,1.5,maxIters=3000,confidence=.995)
    if H is None:return [],None
    valid=valid.ravel().astype(bool)
    predicted=cv2.perspectiveTransform(p[None],H)[0]
    residual=np.linalg.norm(predicted-q,axis=1)
    tracks=[{"from":[round(float(v),2) for v in u],"to":[round(float(v),2) for v in v],"inlier":bool(ok),"fb_error_px":round(float(e),3)} for u,v,ok,e in zip(p,q,valid,fb)]
    count=int(valid.sum())
    if count < 8 or count / len(p) < .6:
        return [], None
    stats={"detected":detected,"fb_accepted":len(p),"inliers":count,"inlier_ratio":count/len(p),"median_fb_error_px":float(np.median(fb)),"median_reprojection_error_px":float(np.median(residual[valid])) if count else None,"median_displacement_px":float(np.median(np.linalg.norm(q[valid]-p[valid],axis=1))) if count else None}
    return tracks,stats

previous=clahe.apply(cv2.cvtColor(images[0],cv2.COLOR_BGR2GRAY))
rows=[]
wheel_cumulative=0.0
wheel_connected=True
sensitivity=[]
for i,t in enumerate(times):
    gray=clahe.apply(cv2.cvtColor(images[i],cv2.COLOR_BGR2GRAY))
    scene_mask=mask_from_rects(roi_at(t,scene_rois))
    cabin_mask=mask_from_rects(roi_at(t,cabin_rois))
    blocked=7.4<=t<=10.6
    row={"t":round(float(t),9),"frame":i+1,"scene_kind":"observed","exterior":[],"scene":None,"wheel":None,"scene_rois":np.round(roi_at(t,scene_rois),1).tolist(),"cabin_roi":np.round(roi_at(t,cabin_rois),1).tolist(),"status":"blocked: passenger occlusion, glare and rapid phone movement" if blocked else "candidate building/tree tracks, pending manual review"}
    if i>0 and not blocked:
        prior_t=times[i-1]
        prior_mask=mask_from_rects(roi_at(prior_t,scene_rois))
        tracks,stats=homography_tracks(previous,gray,prior_mask,scene_mask,.75)
        row["exterior"],row["scene"]=tracks,stats
        if i%30==0:
            for threshold in [.4,1.2]:
                _,alternative=homography_tracks(previous,gray,prior_mask,scene_mask,threshold)
                sensitivity.append({"frame":i+1,"threshold_px":threshold,"stats":alternative})
        cabin=candidates(previous,gray,mask_from_rects(roi_at(prior_t,cabin_rois)),cabin_mask)
        cabin_rotation=None
        if cabin is not None:
            p,q,fb,_=cabin
            affine,valid=similarity(p,q)
            if affine is not None and int(valid.sum())>=8:
                cabin_rotation=float(np.degrees(np.arctan2(affine[1,0],affine[0,0])))
        if t<=3.15:
            wheel=candidates(previous,gray,mask_from_rects(roi_at(prior_t,wheel_rois)),mask_from_rects(roi_at(t,wheel_rois)),.5)
            if wheel is not None and cabin_rotation is not None:
                p,q,fb,_=wheel
                affine,valid=similarity(p,q)
                if affine is not None and int(valid.sum())>=6 and np.mean(valid)>.7:
                    increment=float(np.degrees(np.arctan2(affine[1,0],affine[0,0])))-cabin_rotation
                    if abs(increment)<8:
                        wheel_cumulative+=increment
                        row["wheel"]={
                            "kind":"inferred",
                            "quantity":"apparent wheel-patch image rotation relative to display",
                            "units":"degrees",
                            "increment_deg":increment,
                            "relative_deg":wheel_cumulative if wheel_connected else None,
                            "inliers":int(valid.sum()),
                            "median_fb_error_px":float(np.median(fb)),
                            "points":[[round(float(x),2),round(float(y),2)] for x,y in q[valid.ravel().astype(bool)]],
                            "limitations":"Image-plane similarity only. Perspective and wheel-axis calibration pending. Consecutive integration stops after a tracking gap.",
                        }
            if row["wheel"] is None:wheel_connected=False
    if i == 0:
        row["status"] = "Initial frame: displacement requires a preceding frame."
    elif not blocked and row["scene"] is None:
        row["status"] = "No accepted scene output: insufficient model-consistent tracking support."
    rows.append(row)
    previous=gray
    if i%90==0:print("Tracked frame",i+1,flush=True)

result={
 "schema_version":1,
 "source":{"width":540,"height":960,"frame_count":len(images),"timestamp_basis":"decoded presentation timestamps","source_duration_s":14.97,"nominal_fps":30},
 "method":{"scene":"Shi–Tomasi + pyramidal LK + forward/backward test + per-pair homography RANSAC","fb_threshold_px":.75,"ransac_threshold_px":1.5,"minimum_scene_inliers":8,"minimum_scene_inlier_ratio":.6,"wheel":"local image similarity minus cabin display similarity; experimental","note":"RANSAC inliers are image-model consistent candidates. Independent stationary-scene validation and metric pose remain pending."},
 "frames":rows,
 "telemetry":{"speed_mps":None,"heading_rad":None,"yaw_rate_rad_s":None,"sideslip_rad":None,"steering_wheel_rad":None,"torque_nm":None},
}
(OUT/"observations.json").write_text(json.dumps(result,separators=(",",":"),allow_nan=False))
(OUT/"tracking-sensitivity.json").write_text(json.dumps(sensitivity,indent=2,allow_nan=False))
valid_rows=[r for r in rows if r["scene"] is not None and r["scene"]["inliers"]>=8]
counts=np.array([r["scene"]["inliers"] if r["scene"] else 0 for r in rows])
errors=np.array([r["scene"]["median_fb_error_px"] if r["scene"] else np.nan for r in rows])
flow=np.array([r["scene"]["median_displacement_px"] if r["scene"] else np.nan for r in rows])
wheel_values=np.array([r["wheel"]["increment_deg"] if r["wheel"] else np.nan for r in rows])
summary={
 "decoded_frames":len(images),
 "pairs_with_at_least_8_scene_inliers":len(valid_rows),
 "median_scene_inliers_when_available":float(np.median([r["scene"]["inliers"] for r in valid_rows])),
 "median_fb_error_px":float(np.nanmedian(errors)),
 "blocked_interval_s":[7.4,10.6],
 "wheel_pairs_with_local_rotation":int(np.sum(np.isfinite(wheel_values))),
 "wheel_angle_status":"unavailable: wheel-plane calibration and occlusion validation required",
 "metric_pose_status":"unavailable: no validated video-to-ground correspondences and camera calibration",
}
(OUT/"tracking-summary.json").write_text(json.dumps(summary,indent=2))
plt.rcParams.update({"font.family":"DejaVu Sans","axes.spines.top":False,"axes.spines.right":False})
fig,axes=plt.subplots(4,1,figsize=(11,9),sharex=True,layout="constrained")
for ax,values,label,color in zip(axes,[counts,errors,flow,wheel_values],["Scene inliers (count)","Median round-trip error (px)","Median image motion (px/frame)","Wheel patch minus cabin (deg/frame)"],["#5856d6","#347b74","#5856d6","#a46b12"]):
 ax.plot(times,values,color=color,linewidth=1)
 ax.axvspan(7.4,10.6,color="#d3bd94",alpha=.25)
 ax.set_ylabel(label,fontsize=9);ax.grid(alpha=.2)
axes[-1].set_xlabel("Decoded video time (seconds)")
axes[0].set_title("Image-space tracking diagnostics · shaded interval excluded")
fig.savefig(OUT/"tracking-diagnostics.png",dpi=160)

# Private, silent annotated diagnostic clip. Dimensions and timing are explicit.
container=av.open(str(OUT/"tracking-review.mp4"),"w")
stream=container.add_stream("libx264",rate=30)
stream.width=540;stream.height=960;stream.pix_fmt="yuv420p"
stream.options={"crf":"21","preset":"fast"}
for image,row in zip(images,rows):
 canvas=image.copy()
 for x1,y1,x2,y2 in row["scene_rois"]:
  cv2.rectangle(canvas,(int(x1),int(y1)),(int(x2),int(y2)),(158,139,91),1)
 for track in row["exterior"]:
  p=tuple(np.round(track["from"]).astype(int));q=tuple(np.round(track["to"]).astype(int))
  color=(255,214,90) if track["inlier"] else (81,162,245)
  cv2.arrowedLine(canvas,p,q,color,1,cv2.LINE_AA,tipLength=.3)
  cv2.circle(canvas,q,2,color,-1,cv2.LINE_AA)
 if row["wheel"]:
  for p in row["wheel"]["points"]:
   cv2.circle(canvas,tuple(np.round(p).astype(int)),2,(94,207,255),-1)
 cv2.rectangle(canvas,(0,0),(540,74),(249,249,249),-1)
 label=f'{row["t"]:05.2f}s | frame {row["frame"]} | image-space CV'
 cv2.putText(canvas,label,(10,23),cv2.FONT_HERSHEY_SIMPLEX,.48,(30,30,30),1,cv2.LINE_AA)
 status=f'{row["scene"]["inliers"]} scene inliers' if row["scene"] else "No accepted exterior output"
 cv2.putText(canvas,status,(10,45),cv2.FONT_HERSHEY_SIMPLEX,.44,(70,60,40),1,cv2.LINE_AA)
 cv2.putText(canvas,"Candidate tracks | physical telemetry unavailable",(10,65),cv2.FONT_HERSHEY_SIMPLEX,.4,(70,60,40),1,cv2.LINE_AA)
 frame=av.VideoFrame.from_ndarray(canvas,format="bgr24")
 for packet in stream.encode(frame):container.mux(packet)
for packet in stream.encode():container.mux(packet)
container.close()
print(json.dumps(summary,indent=2))
