"""Retrieve public intersection geometry and georeferenced city imagery."""
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen
from pyproj import Transformer

CACHE=Path(__file__).parent/"cache"
CACHE.mkdir(exist_ok=True)
def get_json(url):
    with urlopen(url,timeout=30) as response:
        return json.load(response)

geocoder="https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates"
query=urlencode({"SingleLine":"E Brooklyn Village Ave & S Brevard St, Charlotte, NC","f":"json","outFields":"Match_addr,Addr_type"})
geocode=get_json(geocoder+"?"+query)
(CACHE/"geocode.json").write_text(json.dumps(geocode,indent=2))
candidate=geocode["candidates"][0]
if candidate["score"]<95 or candidate["attributes"]["Addr_type"]!="StreetInt":
    raise ValueError("Intersection geocode requires review")
location=candidate["location"]
service="https://gis.charlottenc.gov/arcgis/rest/services/WEB/Aerial24/MapServer"
(CACHE/"aerial-service.json").write_text(json.dumps(get_json(service+"?f=pjson"),indent=2))
x,y=Transformer.from_crs(4326,3857,always_xy=True).transform(location["x"],location["y"])
extent=[x-140,y-140,x+140,y+140]
params={"bbox":",".join(map(str,extent)),"bboxSR":3857,"imageSR":3857,"size":"2048,2048","format":"png","f":"json"}
url=service+"/export?"+urlencode(params)
export=get_json(url)
if "href" not in export:raise ValueError(export)
(CACHE/"aerial-export.json").write_text(json.dumps({"request_url":url,"response":export,"intersection":location},indent=2))
with urlopen(export["href"],timeout=30) as response:
    (CACHE/"aerial-2024.png").write_bytes(response.read())
print("Saved georeferenced 2024 aerial and request metadata")
