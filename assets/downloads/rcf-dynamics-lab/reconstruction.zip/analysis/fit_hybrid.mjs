import { readFile, writeFile } from "node:fs/promises";
import { fit, comparisonScore } from "../replay/hybrid-model.mjs";
const directory = new URL("./outputs/", import.meta.url);
const input = JSON.parse(await readFile(new URL("hybrid-input.json", directory)));
const hypotheses = [
  ["Clockwise rotation", { spin: -1 }],
  ["Earlier onset", { spin: -1, onset: 4.5, settle: 11.1, mu: .9 }],
  ["Wider loop", { spin: -1, loopScale: 1.18, onset: 4.5, mu: .9 }],
  ["Lower grip", { spin: -1, mu: .6, onset: 4.5 }],
  ["Counterclockwise rotation", { spin: 1, mu: .9, onset: 4.5 }],
  ["Without image-activity prior", { spin: -1, visualWeight: 0 }],
  ["Unconstrained sideslip", { spin: 1, mu: .9, onset: 4.5, slipWeight: 0 }],
  ["Partial rotation", { spin: 0, onset: 4.6 }],
  ["Delayed recovery", { spin: -1, settle: 12.4, headingBias: 25, mu: .85 }],
];
const solutions = [];
for (const [name, config] of hypotheses) {
  const result = await fit(input, config, { iterations: 45 });
  result.name = name;
  result.summary.selectionScore = comparisonScore(input, result);
  solutions.push(result);
  console.log(name, result.summary);
}
const feasible = solutions.filter((solution) => solution.summary.feasible);
feasible.sort((left, right) => left.summary.selectionScore - right.summary.selectionScore);
const best = feasible[0] || solutions.reduce((left, right) => left.summary.loss < right.summary.loss ? left : right);
const output = {
  version: 1,
  bestName: best.name,
  solutions,
  input,
  uncertainty: "Scenario envelope, expanded by map residual. It has no statistical coverage claim.",
  limitations: [
    "The owner sketch, event timing, heading winding, friction and load remain assumptions.",
    "Image-space CV is preserved separately and supplies visibility context, without a calibrated metric pose residual.",
    "Point-mass force, yaw moment, power and road checks screen plausibility. Tire-force identification is unresolved.",
  ],
};
await writeFile(new URL("hybrid-reconstruction.json", directory), JSON.stringify(output));
