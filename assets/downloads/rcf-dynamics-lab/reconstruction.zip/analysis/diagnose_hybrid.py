"""Audit the hybrid fit, export provenance and plot assumption sensitivity."""
import hashlib
import json
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR",str(Path(__file__).parent/"cache/mpl"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

ROOT=Path(__file__).parent
OUT=ROOT/"outputs"
model=json.loads((OUT/"hybrid-reconstruction.json").read_text())
input_data=model["input"]
best=next(solution for solution in model["solutions"] if solution["name"]==model["bestName"])
alternatives=[solution for solution in model["solutions"] if solution["summary"]["feasible"]]
times=np.array([state["t"] for state in best["states"]])
assert np.all(np.diff(times)>0)
assert len(alternatives)>=3
assert np.allclose(np.sum(input_data["basis"][0],axis=1),1)
assert np.allclose(np.sum(input_data["basis"][1],axis=1),0)
checks=[]
for solution in alternatives:
    states=solution["states"]
    values=lambda key:np.array([state[key] for state in states])
    assert np.allclose(values("speed"),np.hypot(values("vx"),values("vy")))
    assert np.allclose(values("acceleration"),np.hypot(values("ax"),values("ay")))
    assert np.allclose(values("bodyLateral"),-np.sin(values("heading"))*values("ax")+np.cos(values("heading"))*values("ay"))
    for state in states:
        if state["speed"]>.5:
            expected=np.arctan2(np.sin(state["direction"]-state["heading"]),np.cos(state["direction"]-state["heading"]))
            assert abs(state["beta"]-expected)<1e-10
        else:
            assert state["beta"] is None
        assert state["kind"]==("Simulated" if 7.4<=state["t"]<=10.6 else "Estimated")
    interior=(times>.2)&(times<input_data["duration"]-.2)
    interior &= np.array([min(abs(t-k) for k in [3,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5])>.08 for t in times])
    vx_error=np.max(abs(np.gradient(values("x"),times)[interior]-values("vx")[interior]))
    yaw_error=np.max(abs(np.gradient(values("heading"),times)[interior]-values("yaw")[interior]))
    assert vx_error<.04
    assert yaw_error<.04
    assert solution["summary"]["minClearanceM"]>=0
    assert solution["summary"]["maxAccelerationG"]<=solution["config"]["mu"]*1.01
    assert solution["summary"]["maxYawMomentUtilization"]<=1.01
    checks.append({"name":solution["name"],"max_finite_difference_vx_error_mps":float(vx_error),"max_finite_difference_yaw_error_rad_s":float(yaw_error),"screen":solution["summary"]})

# Temporal regression checks from the owner's playback review.
opening=[state for state in best["states"] if state["t"]<=input_data["openingHoldS"]]
assert max(state["speed"] for state in opening)<1e-8
assert max(abs(state["yaw"]) for state in opening)<1e-8
assert np.ptp([state["x"] for state in opening])<1e-8
assert np.ptp([state["y"] for state in opening])<1e-8
exit_states=[state for state in best["states"] if state["t"]>=12]
exit_acceleration=[(state["vx"]*state["ax"]+state["vy"]*state["ay"])/state["speed"] for state in exit_states]
assert max(exit_acceleration)<.08
assert exit_states[-1]["speed"]<=exit_states[0]["speed"]

# Keep original CV and failed checks immutable. Record their current content hashes.
source_hashes={name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ["observations.json","validation.json","tracking-summary.json","map-calibration.json"]}
validation={"checks":checks,"original_evidence_sha256":source_hashes,"timing_refinement":{"opening_hold_s":input_data["openingHoldS"],"exit_speed_at_12_s_mps":exit_states[0]["speed"],"final_speed_mps":exit_states[-1]["speed"],"max_exit_tangential_acceleration_mps2":max(exit_acceleration)},
 "limits":"Screening is conditional on manually outlined road, assumed friction, load, inertia and power efficiency. Individual tire-force feasibility is unresolved."}
(OUT/"hybrid-validation.json").write_text(json.dumps(validation,indent=2))

# Independent time-indexed export with units, category and alternative ranges.
observations=json.loads((OUT/"observations.json").read_text())
metric_definitions={
 "x_m":("x","m"),"y_m":("y","m"),"body_heading_rad":("heading","rad"),
 "velocity_direction_rad":("direction","rad"),"speed_mps":("speed","m/s"),
 "yaw_rate_rad_s":("yaw","rad/s"),"sideslip_rad":("beta","rad"),
 "body_lateral_acceleration_mps2":("bodyLateral","m/s²"),
 "path_normal_acceleration_mps2":("pathNormal","m/s²"),
}
export=[]
for index,state in enumerate(best["states"]):
    metrics={}
    for name,(key,units) in metric_definitions.items():
        candidates=[solution["states"][index][key] for solution in alternatives if solution["states"][index][key] is not None]
        interval=[min(candidates),max(candidates)] if candidates else None
        metrics[name]={"value":state[key],"units":units,"kind":state["kind"] if state[key] is not None else "Unavailable","alternative_range":interval}
    row=observations["frames"][min(len(observations["frames"])-1,int((state["t"]+1e-8)*30))]
    metrics["wheel_patch_increment_deg"]={"value":row["wheel"]["increment_deg"] if row["wheel"] else None,"units":"deg/frame","kind":"Estimated" if row["wheel"] else "Unavailable","note":"Image-plane proxy; road-wheel angle unavailable"}
    metrics["event_torque_nm"]={"value":None,"units":"N m","kind":"Unavailable"}
    export.append({"t":state["t"],"metrics":metrics})
(OUT/"best-estimate.json").write_text(json.dumps({
 "name":best["name"],"provenance":input_data["provenance"],"assumed_parameters":best["config"],"factory_reference":input_data["vehicle"],
 "coordinate_system":"Local UTM 17N east/north offset in metres. Heading and direction measured counterclockwise from east.",
 "uncertainty":"Alternative ranges have no statistical coverage claim. Position also has approximately 1.3 m map-registration sensitivity. Angular ranges may cross the wrap boundary.",
 "samples":export,
},separators=(",",":")))

# Three-pane diagnostic with the requested path, velocity and yaw plots.
plt.rcParams.update({"font.family":"DejaVu Sans","axes.spines.top":False,"axes.spines.right":False})
fig=plt.figure(figsize=(14,8),layout="constrained",facecolor="#fdfdfd")
grid=fig.add_gridspec(2,2,width_ratios=[1.1,1])
map_ax=fig.add_subplot(grid[:,0])
speed_ax=fig.add_subplot(grid[0,1])
yaw_ax=fig.add_subplot(grid[1,1])
# Private aerial source provides calibrated ground axes without screenshot-path dependencies.
aerial=Image.open(ROOT/"cache/aerial-2024.png")
origin=np.array(json.loads((OUT/"map-calibration.json").read_text())["origin_utm_m"])
# Display in the aerial's own pixel coordinates by composing Apple pixel-to-aerial transform.
H=np.array(json.loads((OUT/"map-calibration.json").read_text())["apple_to_aerial_homography"])
world_to_apple=np.array(input_data["worldToApple"])
def pixels(solution):
    points=np.array([[s["x"],s["y"],1] for s in solution["states"]])
    projected=points@world_to_apple.T
    projected/=projected[:,2:]
    aerial_pixels=projected@H.T
    return aerial_pixels[:,:2]/aerial_pixels[:,2:]
map_ax.imshow(aerial)
for solution in alternatives:
    xy=pixels(solution)
    map_ax.plot(xy[:,0],xy[:,1],color="#827f9f",alpha=.4,lw=1)
xy=pixels(best)
map_ax.plot(xy[:,0],xy[:,1],color="#5856d6",lw=2.5,label="Best Estimate")
bridge=(times>=7.4)&(times<=10.6)
map_ax.plot(xy[bridge,0],xy[bridge,1],color="#b77b20",lw=3,label="Simulated bridge")
for t in [0,6,8,10,12,14.97]:
    i=int(np.argmin(abs(times-t)))
    map_ax.scatter(*xy[i],s=22,c="#5856d6",edgecolor="white",zorder=5)
    map_ax.annotate(f"{t:.0f} s",xy[i],xytext=(6,5),textcoords="offset points",fontsize=9,bbox=dict(facecolor="white",alpha=.8,pad=1))
map_ax.set_xlim(820,1370);map_ax.set_ylim(1250,700)
map_ax.set_title("Time-indexed trajectory · city 2024 aerial")
map_ax.set_xlabel("Aerial pixels · approximately 0.112 m per pixel")
map_ax.set_ylabel("Aerial pixels")
map_ax.legend(loc="lower left",fontsize=9)
for ax,key,scale,label in [(speed_ax,"speed",2.2369363,"Ground speed (mph)"),(yaw_ax,"yaw",180/np.pi,"Body yaw rate (deg/s)")]:
    curves=np.array([[state[key]*scale for state in solution["states"]] for solution in alternatives])
    ax.fill_between(times,curves.min(axis=0),curves.max(axis=0),color="#5856d6",alpha=.12,label="Alternative envelope")
    for solution in alternatives:
        ax.plot(times,[s[key]*scale for s in solution["states"]],color="#aaa7b8",alpha=.4,lw=.7)
    ax.plot(times,[s[key]*scale for s in best["states"]],color="#5856d6",lw=2,label="Best Estimate")
    ax.axvspan(7.4,10.6,color="#d7a34c",alpha=.14)
    ax.set_ylabel(label);ax.set_xlabel("Original video time (s)");ax.grid(alpha=.2)
speed_ax.set_title("Velocity sensitivity")
yaw_ax.set_title("Yaw sensitivity · positive counterclockwise")
fig.suptitle("Hybrid reconstruction · assumption-led estimates and model-alternative spread",fontsize=15)
fig.savefig(OUT/"hybrid-diagnostics.png",dpi=160)
(OUT/"hybrid-summary.json").write_text(json.dumps({"best":best["name"],"summary":best["summary"],"config":best["config"],"candidate_count":len(model["solutions"]),"retained_count":len(alternatives)},indent=2))
print(json.dumps({"best":best["name"],"summary":best["summary"],"retained":len(alternatives),"audit":"passed derivative, slip, provenance, screen and timestamp checks"},indent=2))
