from pathlib import Path
import json, re
import numpy as np
from scipy.interpolate import BSpline
from pyproj import Transformer
root=Path(__file__).resolve().parent.parent
cal=json.loads((root/"analysis/outputs/map-calibration.json").read_text())
H=np.array(cal["apple_to_aerial_homography"])
extent=cal["aerial_extent"]
origin=np.array(cal["origin_utm_m"])
to_local=Transformer.from_crs(3857,32617,always_xy=True)
to_map=Transformer.from_crs(32617,3857,always_xy=True)
def apple_world(p):
 p=np.atleast_2d(p); q=np.column_stack([p,np.ones(len(p))])@H.T; q=q[:,:2]/q[:,2:]
 mx=extent["xmin"]+q[:,0]*cal["aerial_resolution_web_mercator_units_per_pixel"]
 my=extent["ymax"]-q[:,1]*cal["aerial_resolution_web_mercator_units_per_pixel"]
 x,y=to_local.transform(mx,my)
 return np.column_stack([x,y])-origin
def world_apple(p):
 p=np.atleast_2d(p)+origin
 mx,my=to_map.transform(p[:,0],p[:,1])
 px=(np.array(mx)-extent["xmin"])/cal["aerial_resolution_web_mercator_units_per_pixel"]
 py=(extent["ymax"]-np.array(my))/cal["aerial_resolution_web_mercator_units_per_pixel"]
 q=np.column_stack([px,py,np.ones(len(p))])@np.linalg.inv(H).T
 return q[:,:2]/q[:,2:]
# Cubic Bezier samples reproduce the supplied sketch geometry as a soft prior.
path = """M475 1539
 C528 1500 577 1459 619 1406 C651 1364 665 1310 665 1262
 C664 1235 646 1201 623 1196 C602 1191 570 1187 554 1194
 C527 1220 488 1251 470 1289 C456 1318 457 1354 470 1366
 C481 1376 512 1381 535 1378 C562 1370 589 1348 601 1330
 C613 1311 615 1271 607 1252 C598 1232 575 1214 557 1191
 C528 1151 498 1100 472 1078 Q461 1068 451 1061"""
nums=re.findall(r'[MCQ]|-?\d+(?:\.\d+)?',path)
i=0; previous=None; phone=[]
while i<len(nums):
 cmd=nums[i];i+=1
 if cmd=="M":
  previous=np.array([float(nums[i]),float(nums[i+1])]);i+=2;phone.append(previous)
 elif cmd=="C":
  coords=np.array(list(map(float,nums[i:i+6]))).reshape(3,2);i+=6
  for u in np.linspace(0,1,14)[1:]:
   phone.append((1-u)**3*previous+3*(1-u)**2*u*coords[0]+3*(1-u)*u*u*coords[1]+u**3*coords[2])
  previous=coords[-1]
 elif cmd=="Q":
  coords=np.array(list(map(float,nums[i:i+4]))).reshape(2,2);i+=4
  for u in np.linspace(0,1,8)[1:]:
   phone.append((1-u)**2*previous+2*(1-u)*u*coords[0]+u*u*coords[1])
  previous=coords[-1]
route=apple_world(np.array(phone)*1.325+[1072,-448])
length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(route,axis=0),axis=1))]
progress=length/length[-1]
# Approximate road-ground envelope, manually outlined from clean screenshot.
road_apple=np.array([[1170,740],[1250,660],[1805,1020],[1880,1060],[2010,1030],[2600,650],[2710,810],[2285,1280],[2240,1390],[2300,1550],[2690,2090],[2510,2240],[2090,1715],[1980,1660],[1750,1640],[1580,1370],[1525,1205]])
road=apple_world(road_apple)
knots=np.r_[[0]*4,[3,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5],[14.97]*4]
sample_t=np.unique(np.r_[np.linspace(0,14.97,91),knots])
raw_n=len(knots)-4
spline=BSpline(knots,np.eye(raw_n),3)
# Sharing the first five cubic coefficients gives an exact C2 hold to 4.5 s.
# Merge their basis columns so every remaining optimization variable is active.
def held_basis(times, derivative):
    raw=spline(times,nu=derivative)
    return np.column_stack([raw[:,:5].sum(axis=1),raw[:,5:]]).tolist()
n=raw_n-4
basis=[held_basis(sample_t,k) for k in range(4)]
dense_t=np.unique(np.r_[np.linspace(0,14.97,450),knots])
dense=[held_basis(dense_t,k) for k in range(4)]
# Approximate projective world-metre to Apple-pixel conversion, affine over local area.
grid=np.array([[x,y] for x in [-45,0,45] for y in [-45,0,45]])
# Use exact planar projective composition estimated from dense local control grid.
import cv2
world_to_apple_h,_=cv2.findHomography(grid.astype(float),world_apple(grid).astype(float),0)
obs=json.loads((root/"analysis/outputs/observations.json").read_text())
support=[int(r["scene"] is not None) for r in obs["frames"]]
activity_scale=float(np.percentile([r["scene"]["median_displacement_px"] for r in obs["frames"] if r["scene"]],95))
activity=[]
for t in sample_t:
    row=obs["frames"][min(len(obs["frames"])-1,int(t*30))]
    scene=row["scene"]
    activity.append({
      "value":min(1.5,scene["median_displacement_px"]/activity_scale) if scene else 0,
      "weight":scene["inlier_ratio"] if scene else 0,
      "wheelQuiet":max(0,1-abs(row["wheel"]["increment_deg"])/.5) if row["wheel"] else 0,
    })
data={
 "version":1,"duration":14.97,"openingHoldS":4.5,"times":sample_t.tolist(),"basis":basis,"denseTimes":dense_t.tolist(),"denseBasis":dense,
 "route":{"progress":progress.tolist(),"xy":route.tolist(),"lengthM":float(length[-1])},
 "road":road.tolist(),"roadApple":road_apple.tolist(),"worldToApple":world_to_apple_h.tolist(),"n":n,
 "vehicle":{"lengthM":4.705,"widthM":1.845,"wheelbaseM":2.730,"curbMassKg":1795,"powerHp":467,"peakEngineTorqueLbFt":389,"drivetrain":"RWD · 8-speed automatic","source":"https://media.lexus.ca/content/dam/media-lexus/general/spec-sheets/16RCF_E.pdf"},
 "trackingSupport":support,"imageActivity":activity,"bridge":[7.4,10.6],"mapErrorM":1.3,
 "defaults":{"onset":4.7,"settle":11.5,"mu":.8,"payload":150,"yawInertiaFactor":1.2,"spin":-1,"sketchWeight":1,"loopScale":1,"entryX":0,"entryY":0,"loopX":0,"loopY":0,"exitX":0,"exitY":0,"headingBias":0,"visualWeight":.15,"efficiency":.85,"slipTargetDeg":45,"slipWeight":1,"exitSpeed":5},
 "provenance":{"map":"Estimated","routeAnchors":"Assumed","eventTiming":"Assumed","payload":"Assumed","friction":"Assumed","inertia":"Assumed","factorySpecifications":"Observed","cv":"Observed image-space candidates; weak normalized activity and early quiet-wheel priors, without metric calibration. Camera motion contaminates these cues. Original validity and failures preserved","trajectory":"Estimated conditional on assumptions; no calibrated video-to-ground pose residual","bridge":"Simulated","uncertainty":"Range across plausible alternatives, not a confidence interval"}
}
(root/"analysis/outputs/hybrid-input.json").write_text(json.dumps(data,separators=(",",":")))
print("Prepared",n,"spline coefficients per state and",round(float(length[-1]),1),"metres of sketch prior")
